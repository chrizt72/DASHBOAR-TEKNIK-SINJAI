import urllib.request
import re

url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vR47zCs1WFP_fsT5O1ml8MtmEo9AmBHTh7Q8Bnquyldge1DgUXHEHJJ-NL57JbWFuv7QdzV5z736gUh/pub"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
try:
    html = urllib.request.urlopen(req).read().decode('utf-8')
    # Find list of sheets
    matches = re.findall(r'\{name: "(.*?)".*?gid: "(\d+)"\}', html)
    if matches:
        for name, gid in matches:
            print(f"Sheet: {name}, GID: {gid}")
    else:
        # Alternative regex if the format is different
        matches2 = re.findall(r'id="sheet-menu-button".*?<ul(.*?)</ul>', html, re.DOTALL)
        if matches2:
            items = re.findall(r'<li.*?id="sheet-button-(.*?)".*?<a.*?>(.*?)</a>', matches2[0])
            for gid, name in items:
                print(f"Sheet: {name}, GID: {gid}")
        else:
            print("Could not parse sheets")
            
except Exception as e:
    print(f"Error: {e}")
